// Video explicativo https://youtu.be/uJ_SOWCLzWU

// Variables
let titulo, play;
let musicaInicio, musicaJuego;
let estado = "inicio";

let escenas = [];             // Escenas inicio
let escenasGrappling = [];    // Escenas elegir el gancho por primera vez a1-e1 
let escenasGrappling2 = [];   // Escenas al elegir el gancho otra ves a2-c2
let indiceEscena = 0;
let ruta = "normal";          
let avanzarBtn;

// aqui estan las escenas de deciciones
let decisionFondo1, grapplingGun, diario;
let decisionFondo2, grapplingGun2, correr;
let decisionFondo3, grapplingGun3, correr2;

// los finales
let final1, final2, final3, final4, epilogo;

// diccionario de diálogos
let dialogos = {};

function preload() {
  titulo = loadImage('titulo.jpg');
  play = loadImage('play.png');

  // Escenas del inicio
  let nombres = ['a.jpg','b.jpg','c.jpg','d.jpg','e.jpg','f.jpg','g.jpg','h.jpg'];
  for (let i = 0; i < nombres.length; i++) {
    escenas.push(loadImage(nombres[i]));
  }

  // Escenas al elegir el gancho la primera vez
  let nombresGrappling = ['a1.jpg','b1.jpg','c1.jpg','d1.jpg'];
  for (let i = 0; i < nombresGrappling.length; i++) {
    escenasGrappling.push(loadImage(nombresGrappling[i]));
  }

  // Escenas la segunda
  let nombresGrappling2 = ['a2.jpg','b2.jpg'];
  for (let i = 0; i < nombresGrappling2.length; i++) {
    escenasGrappling2.push(loadImage(nombresGrappling2[i]));
  }

  avanzarBtn = loadImage('avanzar.png');

  // decisión 1
  decisionFondo1 = loadImage('Desicion1.jpg');
  grapplingGun = loadImage('Grapplinggun.png');
  diario = loadImage('Diario.png');

  // decisión 2
  decisionFondo2 = loadImage('Desicion2.jpg');
  grapplingGun2 = loadImage('Grapplinggun2.png');
  correr = loadImage('correr.png');

  // decisión 3
  decisionFondo3 = loadImage('Desicion3.jpg');
  grapplingGun3 = loadImage('Grapplinggun3.png');
  correr2 = loadImage('correr2.png');

  // finales
  final1 = loadImage('Final1.jpg');
  final2 = loadImage('Final2.jpg');
  final3 = loadImage('Final3.jpg');
  final4 = loadImage('Final4.jpg');

  // Epílogo
  epilogo = loadImage('epilogo.jpg');

  musicaInicio = loadSound('Gravity Falls - Opening Theme Song - HD.mp3');
  musicaJuego = loadSound('Gravity Falls Dreamscaperers Outro Real Loop.mp3');

  // cargar los diálogos 
  dialogos = {
    a: "Es un día tranquilo en Gravity Falls, un día como cualquier otro",
    b: "Así que Mabel decidió ir a jugar afuera con Pato",
    c: "Lo que no esperaba Mabel es que al momento de salir se iba a encontrar con Bill, su máximo enemigo",
    d: "Mabel sorprendida se asusta e intenta escapar antes de que la vea pero ya es muy tarde",
    e: "Dipper, que había aprovechado el lindo día para ir a buscar rarezas al bosque se desconcierta al ver a Bill a lo lejos",
    f: "Al acercarse un poco más sigilosamente se da cuenta que ¡Bill se estaba llevando a su hermana!",
    g: "Rápidamente y casi por instinto vuelve a la cabaña corriendo ya que sabe que allí puede encontrar algo que le sirva para el camino",
    h: "Lo primero que encuentra al llegar son el diario y el gancho de Mabel",
    a1: "Dipper vuelve a salir corriendo pero ahora sí decidido más que nunca a rescatar a Mabel",
    b1: "En el camino, mientras pasaba por el bosque, se cruza con Wendy casualmente",
    c1: "Pensando obviamente que ella aceptaría le pide ayuda",
    d1: "Mientras estaban en camino se cruzan de repente con una burbuja de locura evidentemente puesta por Bill para detenerlos",
    a2: "Ambos logran salir, pero se dan cuenta demasiado tarde de que Wendy salió lastimada, por ello Dipper decide por el bien de ambos seguir solo",
    b2: "Dipper corre, corre y corre hasta que siente que las piernas no le dan más",
    Decision3: "Al volver a toparse con Bill nuevamente tiene que volver a tomar una decisión",
    Final1: "Lamentablemente y sin darse cuenta el diario contenía un hechizo puesto por Bill, este lo hizo dormirse automáticamente",
    Final2: "Ambos deciden seguir corriendo teniendo la fe de salir por algún lado pero lamentablemente ambos se pierden y terminan convertidos en marionetas",
    Final3: "Lamentablemente su intento de distracción no sirvió y Bill lo terminó por capturar también",
    Final4: "Al intentar distraer a Bill golpeándole el ojo con el gancho tuviste tiempo suficiente para rescatar a Mabel y ambos logran escapar",
    Epilogo: "¡Así ambos logran festejar juntos un cumpleaños más todos felices junto a su familia!"
  };
}

function setup() {
  createCanvas(640, 480);
}

function draw() {
  if (estado === "inicio") {
    pantallaInicio();
  } else if (estado === "juego") {
    pantallaJuego();
  }
}

// Mostrar los Dialogos
function mostrarDialogo(clave) {
  if (dialogos[clave]) {
    fill(0, 150);
    rect(0, height - 100, width, 100);
    fill(255);
    textSize(16);
    textAlign(LEFT, TOP);
    textWrap(WORD);
    let margen = 30;
    text(dialogos[clave], margen, height - 90, width - margen * 2);
  }
}

function pantallaInicio() {
  image(titulo, 0, 0, width, height);

  let playWidth = 200, playHeight = 80;
  let playX = width / 2 - playWidth / 2, playY = height - playHeight - 20;
  image(play, playX, playY, playWidth, playHeight);

  if (!musicaInicio.isPlaying()) {
    musicaJuego.stop();
    musicaInicio.loop();
    musicaInicio.setVolume(0.5);
  }
}

function pantallaJuego() {
  background(0);

  // Escenas "NORMALES"
  if (ruta === "normal") {
    let claves = ['a','b','c','d','e','f','g','h'];
    if (indiceEscena < escenas.length) {
      image(escenas[indiceEscena], 0, 0, width, height);
      mostrarDialogo(claves[indiceEscena]);
      let btnWidth = 100, btnHeight = 50;
      let btnX = width - btnWidth - 20, btnY = height/2 - btnHeight/2;
      image(avanzarBtn, btnX, btnY, btnWidth, btnHeight);
    } else {
      ruta = "decision"; 
      indiceEscena = 0;
    }
  } 
  // Dsicion 1
  else if (ruta === "decision") {
    image(decisionFondo1, 0, 0, width, height);
    mostrarDialogo('h');
    let gunWidth = 100, gunHeight = 100;
    let gunX = width / 4 - gunWidth/2, gunY = height / 2 - gunHeight/2;
    image(grapplingGun, gunX, gunY, gunWidth, gunHeight);
    let diarioWidth = 100, diarioHeight = 100;
    let diarioX = width*3/4 - diarioWidth/2, diarioY = height/2 - diarioHeight/2;
    image(diario, diarioX, diarioY, diarioWidth, diarioHeight);
  }
  // Esena gancho 1
  else if (ruta === "grappling") {
    let claves = ['a1','b1','c1','d1'];
    if (indiceEscena < escenasGrappling.length) {
      image(escenasGrappling[indiceEscena], 0, 0, width, height);
      mostrarDialogo(claves[indiceEscena]);
      let btnWidth = 100, btnHeight = 50;
      let btnX = width - btnWidth - 20, btnY = height/2 - btnHeight/2;
      image(avanzarBtn, btnX, btnY, btnWidth, btnHeight);
    } else {
      ruta = "decision2";
      indiceEscena = 0;
    }
  }
  // Descicion 2
  else if (ruta === "decision2") {
    image(decisionFondo2, 0, 0, width, height);
    let gunWidth = 100, gunHeight = 100;
    let gunX = width / 4 - gunWidth/2, gunY = height / 2 - gunHeight/2;
    image(grapplingGun2, gunX, gunY, gunWidth, gunHeight);
    let correrWidth = 100, correrHeight = 100;
    let correrX = width*3/4 - correrWidth/2, correrY = height/2 - correrHeight/2;
    image(correr, correrX, correrY, correrWidth, correrHeight);
  }
  // Esena gancho 2
  else if (ruta === "grappling2") {
    let claves = ['a2','b2'];
    if (indiceEscena < escenasGrappling2.length) {
      image(escenasGrappling2[indiceEscena], 0, 0, width, height);
      mostrarDialogo(claves[indiceEscena]);
      let btnWidth = 100, btnHeight = 50;
      let btnX = width - btnWidth - 20, btnY = height/2 - btnHeight/2;
      image(avanzarBtn, btnX, btnY, btnWidth, btnHeight);
    } else {
      ruta = "decision3"; 
      indiceEscena = 0;
    }
  }
  // Desicion 3
  else if (ruta === "decision3") {
    image(decisionFondo3, 0, 0, width, height);
    mostrarDialogo('Decision3');
    let gunWidth = 100, gunHeight = 100;
    let gunX = width/4 - gunWidth/2, gunY = height/2 - gunHeight/2;
    image(grapplingGun3, gunX, gunY, gunWidth, gunHeight);
    let correrWidth = 100, correrHeight = 100;
    let correrX = width*3/4 - correrWidth/2, correrY = height/2 - correrHeight/2;
    image(correr2, correrX, correrY, correrWidth, correrHeight);
  }
  // Finales
  else if (ruta === "final1") {
    image(final1, 0, 0, width, height);
    mostrarDialogo('Final1');
    fill(255); textSize(20); textAlign(CENTER, TOP);
    text("Pulsa R para volver al menú", width/2, 10);
  }
  else if (ruta === "final2") {
    image(final2, 0, 0, width, height);
    mostrarDialogo('Final2');
    fill(255); textSize(20); textAlign(CENTER, TOP);
    text("Pulsa R para volver al menú", width/2, 10);
  }
  else if (ruta === "final3") {
    image(final3, 0, 0, width, height);
    mostrarDialogo('Final3');
    fill(255); textSize(20); textAlign(CENTER, TOP);
    text("Pulsa R para volver al menú", width/2, 10);
  }
  else if (ruta === "final4") {
    image(final4, 0, 0, width, height);
    mostrarDialogo('Final4');
    let btnWidth = 100, btnHeight = 50;
    let btnX = width - btnWidth - 20, btnY = height/2 - btnHeight/2;
    image(avanzarBtn, btnX, btnY, btnWidth, btnHeight);
  }
  else if (ruta === "epilogo") {
    image(epilogo, 0, 0, width, height);
    mostrarDialogo('Epilogo');
    let btnWidth = 100, btnHeight = 50;
    let btnX = width - btnWidth - 20, btnY = height/2 - btnHeight/2;
    image(avanzarBtn, btnX, btnY, btnWidth, btnHeight);
  }
  // nueva escena: CREDITOS
  else if (ruta === "creditos") {
    background(0);
    fill(255);
    textAlign(CENTER, TOP);
    textSize(36);
    text("CREDITOS", width / 2, 60);
    textSize(22);
    text("Murphy Julian 88352/9", width / 2, height / 2 - 20);
    text("Catalina Schwerdt 122894/8", width / 2, height / 2 + 20);
    fill(180);
    textSize(16);
    text("Pulsa R para volver al menú", width / 2, height - 40);
  }

  // la musica
  if (!musicaJuego.isPlaying()) {
    musicaInicio.stop();
    musicaJuego.loop();
    musicaJuego.setVolume(0.5);
  }
}

// las cosas para el mouse
function mousePressed() {
  if (estado === "inicio") {
    let playWidth = 200, playHeight = 80;
    let playX = width / 2 - playWidth/2, playY = height - playHeight - 20;

    if (mouseX > playX && mouseX < playX + playWidth &&
        mouseY > playY && mouseY < playY + playHeight) {
      estado = "juego";
      ruta = "normal";
      indiceEscena = 0;
    }
  } else if (estado === "juego") {
    // el boton de avanzar
    if (ruta === "normal" || ruta === "grappling" || ruta === "grappling2" || ruta === "epilogo") {
      let btnWidth = 100, btnHeight = 50;
      let btnX = width - btnWidth - 20, btnY = height/2 - btnHeight/2;
      if (mouseX > btnX && mouseX < btnX+btnWidth &&
          mouseY > btnY && mouseY < btnY+btnHeight) {
        if (ruta === "epilogo") {
          ruta = "creditos";
        } else {
          indiceEscena++;
        }
      }
    }

    // decisiones (igual que antes)
    else if (ruta === "decision") {
      let gunWidth = 100, gunHeight = 100;
      let gunX = width/4 - gunWidth/2, gunY = height/2 - gunHeight/2;
      if (mouseX > gunX && mouseX < gunX + gunWidth &&
          mouseY > gunY && mouseY < gunY + gunHeight) {
        ruta = "grappling";
        indiceEscena = 0;
      }

      let diarioWidth = 100, diarioHeight = 100;
      let diarioX = width*3/4 - diarioWidth/2, diarioY = height/2 - diarioHeight/2;
      if (mouseX > diarioX && mouseX < diarioX + diarioWidth &&
          mouseY > diarioY && mouseY < diarioY + diarioHeight) {
        ruta = "final1";
        indiceEscena = 0;
      }
    }

    else if (ruta === "decision2") {
      let gunWidth = 100, gunHeight = 100;
      let gunX = width/4 - gunWidth/2, gunY = height/2 - gunHeight/2;
      if (mouseX > gunX && mouseX < gunX + gunWidth &&
          mouseY > gunY && mouseY < gunY + gunHeight) {
        ruta = "grappling2";
        indiceEscena = 0;
      }

      let correrWidth = 100, correrHeight = 100;
      let correrX = width*3/4 - correrWidth/2, correrY = height/2 - correrHeight/2;
      if (mouseX > correrX && mouseX < correrX + correrWidth &&
          mouseY > correrY && mouseY < correrY + correrHeight) {
        ruta = "final2";
        indiceEscena = 0;
      }
    }

    else if (ruta === "decision3") {
      let gunWidth = 100, gunHeight = 100;
      let gunX = width/4 - gunWidth/2, gunY = height/2 - gunHeight/2;
      if (mouseX > gunX && mouseX < gunX + gunWidth &&
          mouseY > gunY && mouseY < gunY + gunHeight) {
        ruta = "final4";
        indiceEscena = 0;
      }

      let correrWidth = 100, correrHeight = 100;
      let correrX = width*3/4 - correrWidth/2, correrY = height/2 - correrHeight/2;
      if (mouseX > correrX && mouseX < correrX + correrWidth &&
          mouseY > correrY && mouseY < correrY + correrHeight) {
        ruta = "final3";
        indiceEscena = 0;
      }
    }

    // Final 4
    else if (ruta === "final4") {
      let btnWidth = 100, btnHeight = 50;
      let btnX = width - btnWidth - 20, btnY = height/2 - btnHeight/2;
      if (mouseX > btnX && mouseX < btnX+btnWidth &&
          mouseY > btnY && mouseY < btnY+btnHeight) {
        ruta = "epilogo";
        indiceEscena = 0;
      }
    }
  }
}

function keyPressed() {
  if (key === 'r' || key === 'R') {
    estado = "inicio";
    ruta = "normal";
    indiceEscena = 0;
  }
}




